package cs3500.tripletrios.model;



/**
 * Color enum to represent two player colors.
 * The colors are Red for Player Red
 * and Blue for Player Blue.
 */
public enum CardColor {
    RED,
    BLUE;

}