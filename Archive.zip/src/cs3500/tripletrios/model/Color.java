package cs3500.tripletrios.model;

/**
 * Color enum to represent two player colors.
 */
public enum Color {
    RED,
    BLUE;
}